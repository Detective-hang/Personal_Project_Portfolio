/*
************************************************************************************************
��Ҫ�İ����ļ�

�� ��: INCLUDES.C ucos�����ļ�
�� ��: Jean J. Labrosse
************************************************************************************************
*/

#ifndef __INCLUDES_H__
#define __INCLUDES_H__
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>

#include "uCOS_II.H"
#include "os_cpu.h"
#include "os_cfg.h"

//#include "stm32f10x_lib.h"
#include "stm32f10x_map.h"

#endif































