#include "beep.h"
#include "includes.h"


//int tunes[] = {0,261,293,329,349,392,440,493};

int tunes[] = {0,392,440,494,523,587,659,740,784,880,988,1047,1175,1319,1480,1568};
int lowNEight = 1; // �˶ȿ���

void Beep_Init()
{
    RCC->APB2ENR |= 1 << 6;
    GPIOE->CRL &= 0XFF0FFFFF;
    GPIOE->CRL |= 0X00300000;
    GPIOE->ODR &= 0x00000000;
}

void Beep_Number(int tune, int last)
{
    int i = 0;
    float cycle_us = 1000000.0 / tunes[tune] / lowNEight;
    int total_cycles = last * tunes[tune] * lowNEight / 1000;
    
    for(; i < total_cycles; i++){
        if(tune != 0) BEEP = ~BEEP;
        delay_us(cycle_us);
    }
    BEEP = 0;
}

