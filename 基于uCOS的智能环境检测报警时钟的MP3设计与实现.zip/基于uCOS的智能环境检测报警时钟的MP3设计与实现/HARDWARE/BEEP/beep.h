#include "sys.h"
#include "delay.h"

#define BEEP PEout(5)


void Beep_Init(void);
void Beep_Number(int tune,int last);
